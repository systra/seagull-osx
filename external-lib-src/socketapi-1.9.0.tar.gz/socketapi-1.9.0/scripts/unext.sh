#!/bin/sh
sed -f unext.sed $@
