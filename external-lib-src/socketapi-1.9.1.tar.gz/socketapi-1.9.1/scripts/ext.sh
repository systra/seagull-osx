#!/bin/sh
sed -f ext.sed $@
